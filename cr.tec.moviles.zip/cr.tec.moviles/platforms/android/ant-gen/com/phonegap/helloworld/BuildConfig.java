/** Automatically generated file. DO NOT MODIFY */
package com.phonegap.helloworld;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}